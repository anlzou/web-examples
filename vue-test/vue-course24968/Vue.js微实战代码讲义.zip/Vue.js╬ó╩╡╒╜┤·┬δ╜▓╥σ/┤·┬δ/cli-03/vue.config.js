module.exports = {
    devServer : {
        proxy : 'http://v.juhe.cn/todayOnhistory'
    }
}