module.exports = {
    devServer : {
        proxy : 'http://apis.juhe.cn/mobile'
    }
}